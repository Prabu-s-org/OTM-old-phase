<li class="menu-title"><span data-key="t-menu">Menu</span></li>

<?php
//Main Screen Begins
$main_screens  = main_screen();

// print_r($_SESSION['main_screens']);
foreach ($main_screens as $main_key => $main_value) {

    // Menu Permission based on User type Begin
    if (in_array($main_value['unique_id'], $_SESSION['main_screens'])) {

        $menu_main_name    =  disname($main_value["screen_main_name"]);

        $menu_main_icon    = "";

        if ($main_value["icon_name"]) {
            $menu_main_icon    =  '<i class="' . $main_value["icon_name"] . ' me-1"></i>';
        }
?>

        <li class="nav-item">
            <a class="nav-link menu-link" href="#sidebarDashboards<?= $main_value["unique_id"]; ?>" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarDashboards<?= $main_value["unique_id"]; ?>">
                <?= $menu_main_icon; ?> <span data-key="t-dashboards"><?php echo $menu_main_name; ?></span>
            </a>
            <div class="collapse menu-dropdown" id="sidebarDashboards<?= $main_value["unique_id"]; ?>">
                <ul class="nav nav-sm flex-column">
                    <?php
                    $user_screens   = user_screen('', $main_value['unique_id']);

                    foreach ($user_screens as $screens_key => $screens_value) {
                        // User Screen Permission Based On User Type
                        if (in_array($screens_value['unique_id'], $_SESSION['screens'])) {

                            $menu_screen_name   = disname($screens_value["screen_name"]);
                            $menu_screen_folder = $screens_value["folder_name"];
                            $menu_screen_icon   = "";


                            $menu_screen    = $menu_screen_folder . "/list";
                            // $file_name      = base64_encode(openssl_encrypt($menu_screen, $enc_method, $enc_password, OPENSSL_RAW_DATA, $enc_iv));

                    ?>
                            <li class="nav-item">
                                <a href="index.php?file=<?php echo $menu_screen; ?>" class="nav-link" data-key="t-analytics"> <?= $menu_screen_name; ?> </a>

                            </li>

                    <?php }
                    }

                    // $city = base64_encode('city_creation/list');


                    ?>

                    <li>

                </ul>

            </div>
            <?php
            $pincode   = "pincode_creation/list";
            $department    = "department_creation/list";
            $consignee    = "consignee_creation/list";
            $executive = "executive_creation/list";
            $item_creation = "item_creation/list";
            $main_category = "main_category/list";
            $product_category = "product_category/list";

            $po_form = "po_form/list";
            $stock_position = "stock_position/list";
            $invoice = "invoice/list";
            $doc_approval = "doc_apporval/list";
            $dispatch = "dispatch/list";
            $sign_doc = "signed_document_vertification/list";
            $bg = "bg/list";
            $elcot_entry = "elcot_entry/list";
            $bill_submission = "bill_submission/list";

            // $pincode      = base64_encode(openssl_encrypt($pincode, $enc_method, $enc_password, OPENSSL_RAW_DATA, $enc_iv));
            // $department     = base64_encode(openssl_encrypt($department, $enc_method, $enc_password, OPENSSL_RAW_DATA, $enc_iv));
            // $consignee     = base64_encode(openssl_encrypt($consignee, $enc_method, $enc_password, OPENSSL_RAW_DATA, $enc_iv));
            // $executive     = base64_encode(openssl_encrypt($executive, $enc_method, $enc_password, OPENSSL_RAW_DATA, $enc_iv));
            // $item_creation     = base64_encode(openssl_encrypt($item_creation, $enc_method, $enc_password, OPENSSL_RAW_DATA, $enc_iv));
            // $main_category     = base64_encode(openssl_encrypt($main_category, $enc_method, $enc_password, OPENSSL_RAW_DATA, $enc_iv));
            // $product_category     = base64_encode(openssl_encrypt($product_category, $enc_method, $enc_password, OPENSSL_RAW_DATA, $enc_iv));

            // $stock_position     = base64_encode(openssl_encrypt($stock_position, $enc_method, $enc_password, OPENSSL_RAW_DATA, $enc_iv));
            // $po_form     = base64_encode(openssl_encrypt($po_form, $enc_method, $enc_password, OPENSSL_RAW_DATA, $enc_iv));
            // $doc_approval     = base64_encode(openssl_encrypt($doc_approval, $enc_method, $enc_password, OPENSSL_RAW_DATA, $enc_iv));
            // $invoice     = base64_encode(openssl_encrypt($invoice, $enc_method, $enc_password, OPENSSL_RAW_DATA, $enc_iv));
            // $dispatch     = base64_encode(openssl_encrypt($dispatch, $enc_method, $enc_password, OPENSSL_RAW_DATA, $enc_iv));
            // $sign_doc     = base64_encode(openssl_encrypt($sign_doc, $enc_method, $enc_password, OPENSSL_RAW_DATA, $enc_iv));
            // $bg     = base64_encode(openssl_encrypt($bg, $enc_method, $enc_password, OPENSSL_RAW_DATA, $enc_iv));
            // $elcot_entry     = base64_encode(openssl_encrypt($elcot_entry, $enc_method, $enc_password, OPENSSL_RAW_DATA, $enc_iv));
            // $bill_submission     = base64_encode(openssl_encrypt($bill_submission, $enc_method, $enc_password, OPENSSL_RAW_DATA, $enc_iv));
            ?>
        </li> <!-- end Dashboard Menu -->
<?php
    }
}
?>
<a href="index.php?file=<?php echo $pincode; ?>" class="nav-link" data-key="t-analytics">Pincode Creation </a>
<a href="index.php?file=<?php echo $department; ?>" class="nav-link" data-key="t-analytics">Department Creation </a>
<a href="index.php?file=<?php echo $consignee; ?>" class="nav-link" data-key="t-analytics">Consignee Creation </a>
<a href="index.php?file=<?php echo $executive; ?>" class="nav-link" data-key="t-analytics">Executive Creation </a>
<!-- <a href="index.php?file=<?php echo $item_creation; ?>" class="nav-link" data-key="t-analytics">Item Creation </a> -->
<a href="index.php?file=<?php echo $main_category; ?>" class="nav-link" data-key="t-analytics">Main Category</a>

<a href="index.php?file=<?php echo $product_category; ?>" class="nav-link" data-key="t-analytics">Product Category</a><br>
<hr>
<h5 style="color:white;margin-left:1.25rem">Forms</h5>
<a href="index.php?file=<?php echo $po_form; ?>" class="nav-link" data-key="t-analytics">Purchase Order</a>
<a href="index.php?file=<?php echo $stock_position; ?>" class="nav-link" data-key="t-analytics">Stock Position</a>
<a href="index.php?file=<?php echo $invoice; ?>" class="nav-link" data-key="t-analytics">Invoice</a>
<a href="index.php?file=<?php echo $doc_approval; ?>" class="nav-link" data-key="t-analytics">Document Approval</a>
<a href="index.php?file=<?php echo $dispatch; ?>" class="nav-link" data-key="t-analytics">Dispatch</a>
<a href="index.php?file=<?php echo $sign_doc; ?>" class="nav-link" data-key="t-analytics">Signed Doc. Verification</a>
<a href="index.php?file=<?php echo $bg; ?>" class="nav-link" data-key="t-analytics">BG</a>
<a href="index.php?file=<?php echo $elcot_entry; ?>" class="nav-link" data-key="t-analytics">Elcot Entry</a>
<a href="index.php?file=<?php echo $bill_submission; ?>" class="nav-link" data-key="t-analytics">Bill Submission</a>


</ul>