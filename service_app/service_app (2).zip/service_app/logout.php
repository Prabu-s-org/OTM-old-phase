<?php
error_reporting(0);
// header("Cache-Control: no-cache, must-revalidate");
// header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
// header("Content-Type: application/xml; charset=utf-8");
session_destroy();
// echo '<script>window.reload();</script>';
header('Location:http://122.165.127.123/aed_elcot/service_app/index.php');



?>