<?php
include '../service_app/config/dbconfig.php';
session_start();


$table             = "view_installation_followups";
$table_install             = "view_installation_followups1";
$table_sub             = "installation_details";
$table_sub_dc         = "dc_ir_doc_dispatch_details";
$table_inst_sublist = "installation_details_sublist";
// $table_inv="view_invoice_creation_main";
$table_inv="invoice_creation_main";
function unique_id($prefix = "") {

    $unique_id = uniqid().rand(10000,99999);
    // print_r($unique_id);
    if($prefix) {
        $unique_id = $prefix.$unique_id;
    }
    
    return $unique_id;
    }
// print_r($unique_id);
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    if ($action == 'loginUser') {
        $user_name = trim($_POST['user_name']);
        $password = trim($_POST['password']);

        if (empty($user_name) || empty($password)) {
            echo json_encode(['status' => false, 'msg' => 'All fields are required.']);
            exit;
        }

        try {
            $sql = "SELECT user_type_unique_id, staff_name, staff_id, unique_id, password, 
                           (SELECT staff_name FROM view_login WHERE unique_id = user.unique_id) AS eng_unique_id 
                    FROM user 
                    WHERE user_name = :user_name 
                    AND is_delete = 0 
                    AND is_active = 1";

            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':user_name', $user_name, PDO::PARAM_STR);
            $stmt->execute();

            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user) {
                echo json_encode(['status' => false, 'msg' => 'Invalid username or password']);
                exit;
            }

            // Check if password is hashed or plain text
            if (password_verify($password, $user['password']) || $password == $user['password']) {
                $_SESSION['user_id'] = $user['unique_id'];
                $_SESSION['staff_id'] = $user['staff_id'];
                $_SESSION['eng_unique_id'] = $user['eng_unique_id'];
                $_SESSION['staff_name'] = $user['staff_name'];
                $_SESSION['user_name'] = $user_name;
                $_SESSION['user_type_unique_id'] = $user['user_type_unique_id'];

                echo json_encode([
                    'status' => true,
                    'msg' => 'Login successful',
                    'session' => $_SESSION
                ]);
            } else {
                echo json_encode(['status' => false, 'msg' => 'Invalid username or password']);
            }

            exit;
        } catch (PDOException $e) {
            echo json_encode(['status' => false, 'msg' => 'Database error: ' . $e->getMessage()]);
            exit;
        }
    }

      else if ( $action == 'datatable' ) {
        // DataTable Handling
        $search = $_POST[ 'search' ][ 'value' ] ?? '';
        $length = $_POST[ 'length' ] ?? 10;
        $start = $_POST[ 'start' ] ?? 0;
        $draw = $_POST[ 'draw' ] ?? 1;

        $columns = [
            "'' as s_no",
            'po_num',
            'po_date',
            'ledger_name',
            '(SELECT district_name FROM district_creation WHERE district_creation.unique_id = view_installation_followups.con_district) AS con_district',
            'con_address',
            'invoice_no',
            "DATE_FORMAT(invoice_date, '%d-%m-%Y') AS invoice_date",
            'invoice_value',
            'po_file_name',
            'dc_file_name',
            'ir_file_name',
            'file_invoice',
            '(SELECT staff_name FROM view_login WHERE view_login.unique_id = view_installation_followups.engineer_name) AS engineer_name',
            'installation_status',
            'delivery_due_dates',
            'consignee_unique_id',
            'form_main_unique_id',
            'con_pincode',
            'dc_required',
            'invoice_auto_id',
            'form_main_unique_id',
        ];

        $table = 'view_installation_followups';
        $order_by = 'po_date DESC';

        $where = '1 = 1';
        if ( !empty( $search ) ) {
            $where .= " AND (po_num LIKE '%$search%' OR ledger_name LIKE '%$search%' OR con_district LIKE '%$search%')";
        }

        // Fetch Data
        $sql_function = 'SQL_CALC_FOUND_ROWS';
        $result = $pdo->select( [ $table, $columns ], $where, $length, $start, $order_by, $sql_function );
        

        if ( $result->status ) {
            $res_array = $result->data;
            $base_url = '/elcot_ots/uploads/installation/';

            foreach ( $res_array as $key => &$value ) {
                $value[ 's_no' ] = $start + $key + 1;
                $pdf_icon = "<i class='fa fa-file-pdf-o' style='color:red; font-size:20px;'></i>";

                // Generate clickable PDF links
                foreach ( [ 'po_file_name', 'dc_file_name', 'ir_file_name' ] as $file ) {
                    $value[ $file ] = !empty( $value[ $file ] )
                    ? "<a href='$base_url{$value[$file]}' target='_blank'>$pdf_icon</a>"
                    : '-';
                }

                // Delivery Due Date Calculation
                $po_date = strip_tags( $value[ 'po_date' ] );
                $poDate = DateTime::createFromFormat( 'Y-m-d', $po_date );
                $delivery_due_days = ( int )$value[ 'delivery_due_dates' ];

                if ( $poDate && $delivery_due_days > 0 ) {
                    $poDate->modify( "+$delivery_due_days days" );
                    $value[ 'delivery_due_dates' ] = "<span class='po_date'>{$poDate->format('d-m-Y')}</span>";
                } else {
                    $value[ 'delivery_due_dates' ] = '-';
                }

                $value[ 'actions' ] = "<a href='form.php?unique_id={$value['consignee_unique_id']}&invoice_no={$value['invoice_auto_id']}' class='btn btn-sm btn-primary'>Edit</a>";
            }

            echo json_encode( [
                'draw' => intval( $draw ),
                'recordsTotal' => count( $res_array ),
                'recordsFiltered' => count( $res_array ),
                'data' => $res_array
            ] );
        } else {
            echo json_encode( [
                'draw' => intval( $draw ),
                'recordsTotal' => 0,
                'recordsFiltered' => 0,
                'data' => []
            ] );
        }
    } 
    else if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'fetchlist') {
        try {
            session_start();
            if (!isset($_SESSION['user_name'])) {
                echo json_encode(['status' => false, 'msg' => 'User session not found']);
                exit;
            }
    
            $userName = $_SESSION['user_name'];
            // SQL Query
            $sql = "SELECT 
                        v.po_num, 
                        DATE_FORMAT(v.po_date, '%d-%m-%Y') AS po_date, 
                        v.invoice_value,
                        v.invoice_no, 
                        DATE_FORMAT(v.invoice_date, '%d-%m-%Y') AS invoice_date, 
                        d.district_name AS con_district,
                        v.con_address,     
                        l.staff_name AS engineer_name,
                        v.dc_file_name, 
                        v.ir_file_name,
                        v.consignee_unique_id,
                        v.invoice_auto_id,
                        v.installation_status
                    FROM view_installation_followups v
                    JOIN view_login l ON v.engineer_name = l.unique_id
                    LEFT JOIN district_creation d ON d.unique_id = v.con_district
                    WHERE l.staff_name = :user_name";
    
            // Prepare and Execute Query
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':user_name', $userName, PDO::PARAM_STR);
            $stmt->execute();
            // print_r($stmt);
            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
          // Append action buttons dynamically
// Append action buttons dynamically
foreach ($data as &$row) {
    $dc_file_name = trim($row['dc_file_name'] ?? '');  // Trim to remove spaces
    $ir_file_name = trim($row['ir_file_name'] ?? '');  // Trim to remove spaces

    $actionIcons = "<div class='col-12 col-sm-12 col-md-12 col-lg-12 form-icons'>";

    if ($dc_file_name !== '' && $ir_file_name !== '') {
        // Both files are present, show only the view icon
        $actionIcons .= "<i class='bi bi-eye blue view-icon'  
                        data-unique_id='" . htmlspecialchars($row['consignee_unique_id']) . "' 
                        data-invoice_no='" . htmlspecialchars($row['invoice_no']) . "'></i>";
    } else {
        // Either one or both files are missing, show edit & delete icons
        $actionIcons .= "<i class='bi bi-pen green edit-icon' 
                        data-unique_id='" . htmlspecialchars($row['consignee_unique_id']) . "' 
                        data-invoice_no='" . htmlspecialchars($row['invoice_no']) . "'></i>
                        <i class='bi bi-trash3 red delete-icon'></i>";
    }

    $actionIcons .= "</div>";
    $row['actions'] = $actionIcons;
}
            echo json_encode(['status' => true, 'data' => $data]);
        } catch (PDOException $e) {
            echo json_encode(['status' => false, 'msg' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }
    elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'tab2list') {
        try {
            session_start();
            if (!isset($_SESSION['user_name'])) {
                echo json_encode(['status' => false, 'msg' => 'User session not found']);
                exit;
            }
    
            $userName = $_SESSION['user_name'];
            error_log("Session User Name: " . $userName);
    
            $sql = "SELECT 
                        po_num,  
                        po_date,
                        (SELECT ledger_name FROM department_creation_sublist 
                         WHERE department_creation_sublist.unique_id = view_installation_followups.ledger_name) AS ledger_name,
                        (SELECT district_name FROM district_creation 
                         WHERE district_creation.unique_id = view_installation_followups.con_district) AS con_district,
                        con_address,
                        invoice_no, 
                        DATE_FORMAT(invoice_date, '%d-%m-%Y') AS invoice_date, 
                        invoice_value,
                        (SELECT staff_name FROM view_login 
                         WHERE view_login.unique_id = view_installation_followups.engineer_name) AS engineer_name,
                        consignee_unique_id,
                        invoice_auto_id,
                        dc_file_name,
                        ir_file_name
                    FROM view_installation_followups";
    
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
            echo json_encode(['status' => true, 'data' => $data]);
        } catch (PDOException $e) {
            echo json_encode(['status' => false, 'msg' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }
    
    
 else if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'dc_ir_add_update') {
        
        $po_form_unique_id = trim($_POST['po_form_unique_id'] ?? '');
        $invoice_no = trim($_POST['invoice_no'] ?? '');
        $consignee_id = trim($_POST['consignee_id'] ?? '');
        $dc_dispatch_mode = trim($_POST['dc_dispatch_mode'] ?? '');
        $ir_dispatch_mode = trim($_POST['ir_dispatch_mode'] ?? '');
        $snr_dispatch_mode = trim($_POST['snr_dispatch_mode'] ?? '');
        $dc_required = trim($_POST['dc_required'] ?? '');
        $without_snr = trim($_POST['without_snr'] ?? '');
    
        if (empty($po_form_unique_id) || empty($invoice_no) || empty($consignee_id)) {
            echo json_encode(['status' => false, 'msg' => 'Missing required fields.']);
            exit;
        }
    
        // Check if invoice exists
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM table_sub_dc WHERE is_delete = 0 AND invoice_no = ?");
        $stmt->execute([$invoice_no]);
        $invoice_count = $stmt->fetchColumn();
    
        if (!$invoice_count) {
            echo json_encode(['status' => false, 'msg' => 'Invoice not found.']);
            exit;
        }
    
        // Update status based on dispatch conditions
        $update_where = " consignee_unique_id = ? AND invoice_no = ?";
        $params = [$po_form_unique_id, $consignee_id, $invoice_no];
    
        if (!empty($dc_dispatch_mode) && !empty($ir_dispatch_mode) && empty($snr_dispatch_mode)) {
            $query = "UPDATE table_sub SET dc_delivery_status = 3, without_snr = ? WHERE $update_where";
            array_push($params, $without_snr);
        } elseif (!empty($dc_dispatch_mode) && empty($snr_dispatch_mode) && empty($ir_dispatch_mode) && $dc_required !== 'on') {
            $query = "UPDATE table_sub SET dc_delivery_status = 5 WHERE $update_where";
        } elseif (!empty($dc_dispatch_mode) && !empty($ir_dispatch_mode) && !empty($snr_dispatch_mode)) {
            $query = "UPDATE table_sub SET dc_delivery_status = 3 WHERE $update_where";
        }
    
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
    
        echo json_encode(['status' => true, 'msg' => 'Data updated successfully.']);
    }
    
    else if ( $_POST[ 'action' ] == 'createupdate' ) {
        // print_r("cfvgbh");
       $po_num          = $_POST['po_num'];
       $po_unique_id          = $_POST['po_unique_id'];
        $form_main_unique_id          = $_POST['po_form_unique_id'];
        $po_date              = $_POST['po_date'];
       $invoice_auto_id = $_POST['invoice_auto_id'];
       $invoice_no            = $_POST['invoice_no'];
       // $no_of_consignee     = $_POST['no_of_consignee'];
       $invoice_date        = $_POST['invoice_date'];
       $consignee_unique_id            = $_POST['consignee_unique_id'];
    //    echo $engineer_name              = $_POST['engineer_name'];
       $installation_com_date              = $_POST['installation_com_date'];
       $eng_remarks              = $_POST['eng_remarks'];
       $engineer_id = $_POST['engineer_id'];
    //    $engg_type              = $_POST['engg_type'];
    //    $eng_remarks            = $_POST['eng_remarks'];
       $documents_type              = $_POST['documents_type'];
       echo $documents_type1              = $_POST['documents_type1'];
       $documents_type2              = $_POST['documents_type2'];
       $dc_received_sts             = $_POST['dc_received_sts'];
       $dc_cus_signed_date       = $_POST['dc_cus_signed_date'];
      echo  $ir_rec_status            = $_POST['ir_rec_status'];
       echo $ir_cus_signed_date          = $_POST['ir_cus_signed_date'];
       $snr_rec_status              = $_POST['snr_rec_status'];
       $snr_cus_signed_date             = $_POST['snr_cus_signed_date'];
       $unique_id             = $_POST['unique_id'];
       $dc_required          = $_POST['dc_required'];

    $upload_dir = "../uploads/installation"; // Change this to your desired upload folder
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true); // Create the directory if it doesn't exist
}

$file_names = "";
$file_org_names = "";
if (isset($_FILES["test_file"]) && is_array($_FILES["test_file"]["name"])) {
    foreach ($_FILES["test_file"]["name"] as $index => $file_name) {
        if (!empty($file_name)) {
            $file_tmp = $_FILES["test_file"]["tmp_name"][$index];
            $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
            $new_name = uniqid() . "." . $file_ext;
            $destination = $upload_dir . $new_name;

            if (move_uploaded_file($file_tmp, $destination)) {
                $file_names .= $new_name . ",";
                $file_org_names .= $file_name . ",";
            }
        }
    }
} elseif (!empty($_FILES["test_file"]["name"])) {
    $file_tmp = $_FILES["test_file"]["tmp_name"];
    $file_name = $_FILES["test_file"]["name"];
    $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
    $new_name = uniqid() . "." . $file_ext;
    $destination = $upload_dir . $new_name;

    if (move_uploaded_file($file_tmp, $destination)) {
         $file_names = $new_name;
       $file_org_names = $file_name;
    }
}

// Handling `test_file1` upload
$ir_file_names = "";
$ir_file_org_names = "";
if (isset($_FILES["test_file1"]) && is_array($_FILES["test_file1"]["name"])) {
    foreach ($_FILES["test_file1"]["name"] as $index => $file_name) {
        if (!empty($file_name)) {
            $file_tmp = $_FILES["test_file1"]["tmp_name"][$index];
            $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
            $new_name = uniqid() . "." . $file_ext;
            $destination = $upload_dir . $new_name;

            if (move_uploaded_file($file_tmp, $destination)) {
                $ir_file_names .= $new_name . ",";
                $ir_file_org_names .= $file_name . ",";
            }
        }
    }
} elseif (!empty($_FILES["test_file1"]["name"])) {
    $file_tmp = $_FILES["test_file1"]["tmp_name"];
    $file_name = $_FILES["test_file1"]["name"];
    $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
    $new_name = uniqid() . "." . $file_ext;
    $destination = $upload_dir . $new_name;

    if (move_uploaded_file($file_tmp, $destination)) {
        $ir_file_names = $new_name;
        $ir_file_org_names = $file_name;
    }
}

// Handling `test_file2` upload
$snr_file_names = "";
$snr_file_org_names = "";
if (isset($_FILES["test_file2"]) && is_array($_FILES["test_file2"]["name"])) {
    foreach ($_FILES["test_file2"]["name"] as $index => $file_name) {
        if (!empty($file_name)) {
            $file_tmp = $_FILES["test_file2"]["tmp_name"][$index];
            $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
            $new_name = uniqid() . "." . $file_ext;
            $destination = $upload_dir . $new_name;

            if (move_uploaded_file($file_tmp, $destination)) {
                $snr_file_names .= $new_name . ",";
                $snr_file_org_names .= $file_name . ",";
            }
        }
    }
} elseif (!empty($_FILES["test_file2"]["name"])) {
    $file_tmp = $_FILES["test_file2"]["tmp_name"];
    $file_name = $_FILES["test_file2"]["name"];
    $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
    $new_name = uniqid() . "." . $file_ext;
    $destination = $upload_dir . $new_name;

    if (move_uploaded_file($file_tmp, $destination)) {
        $snr_file_names = $new_name;
        $snr_file_org_names = $file_name;
    }
}
$generated_unique_id = unique_id($prefix);
 $update_where = ''; 
 
       if (($file_names) && ($file_org_names)  || ($snr_file_names) && ($snr_file_org_names) || ($ir_file_names) && ($ir_file_org_names)) {
        // print_r("123");
           $columns            = [
             'po_num'        => $po_num,
               'po_auto_id'        => $po_unique_id,
               'po_date'           => $po_date,
               'invoice_auto_id'     => $invoice_auto_id,
               'invoice_no'   => $invoice_no,
               'invoice_date'   => $invoice_date,
               'consignee_unique_id'   => $consignee_unique_id,
               'engineer_name'              => $engineer_id,
               'installation_com_date'             => $installation_com_date,
               'eng_remarks' => $eng_remarks,
               'engineer_id' => $engineer_id,
            //    'eng_remarks'             => $eng_remarks,
               'documents_type'              => $documents_type,
               'documents_type1'              => $documents_type1,
               'documents_type2'              => $documents_type2,
               'dc_received_sts'             => $dc_received_sts,
               'dc_cus_signed_date'             => $dc_cus_signed_date,
               'ir_rec_status'              => $ir_rec_status,
               'ir_cus_signed_date'         => $ir_cus_signed_date,
               'snr_rec_status'             => $snr_rec_status,
               'snr_cus_signed_date'             => $snr_cus_signed_date,
               'dc_file'               => $file_names,
               'dc_original_name'     => $file_org_names,
               'ir_file'           => $ir_file_names,
               'ir_original_name'  => $ir_file_org_names,
               'snr_file'          => $snr_file_names,
               'dc_required'          => $dc_required,
               // 'unique_id'          => $unique_id,
               'snr_original_name'  => $snr_file_org_names,
               'po_form_unique_id'   => $form_main_unique_id,

               'installation_date'         => $installation_date,
               'unique_id'              => $generated_unique_id,
           ];
        //    print_r($columns);
       }

       if (($file_names) && ($file_org_names)) {
// print_r("cfvgbh");
           $columns            = [
               'po_num'        => $po_num,
               'po_auto_id'        => $po_unique_id,
               'po_date'           => $po_date,
               'invoice_auto_id'     => $invoice_auto_id,
               'invoice_no'   => $invoice_no,
               'invoice_date'   => $invoice_date,
               'consignee_unique_id'   => $consignee_unique_id,
              'consignee_unique_id'   => $consignee_unique_id,
               'engineer_name'              => $engineer_id,
               'installation_com_date'             => $installation_com_date,
               'eng_remarks' => $eng_remarks,
             'engineer_id' => $engineer_id,
                 // $eng_remarks            = $_POST['eng_remarks'];
            //    'eng_remarks'             => $eng_remarks,
               'documents_type'              => $documents_type,
               'documents_type1'              => $documents_type1,
               'documents_type2'              => $documents_type2,
               'dc_received_sts'             => $dc_received_sts,
               'dc_cus_signed_date'             => $dc_cus_signed_date,
               'ir_rec_status'              => $ir_rec_status,
               'ir_cus_signed_date'         => $ir_cus_signed_date,
               'snr_rec_status'             => $snr_rec_status,
               'snr_cus_signed_date'             => $snr_cus_signed_date,
               'dc_file'               => $file_names,
               'dc_original_name'     => $file_org_names,
               'dc_required'          => $dc_required,
               'ir_file'           => $ir_file_names,
               'ir_original_name'  => $ir_file_org_names,
               'snr_file'          => $snr_file_names,
               // 'form_unique_id'          => $form_unique_id,
               'snr_original_name'  => $snr_file_org_names,
               'po_form_unique_id'   => $form_main_unique_id,
               'installation_date'         => $installation_date,
               // 'installation_id'              => ins_no_get(),
               'unique_id'              =>$generated_unique_id
           ];
       }
    //   print_r($columns);
       if (($ir_file_names) && ($ir_file_org_names)) {
        // print_r("fzv");

           // if(($dc_file_data) &&($dc_file_name) &&($snr_file_data) && ($snr_file_name)) {
               $columns            = [
                   'po_num'        => $po_num,
                   'po_auto_id'        => $po_unique_id,
                   'po_date'           => $po_date,
                   'invoice_auto_id'     => $invoice_auto_id,
                   'invoice_no'   => $invoice_no,
                   'invoice_date'   => $invoice_date,
                   'consignee_unique_id'   => $consignee_unique_id,
                  'consignee_unique_id'   => $consignee_unique_id,
               'engineer_name'              => $engineer_id,
               'installation_com_date'             => $installation_com_date,
               'eng_remarks' => $eng_remarks,
            'engineer_id' => $engineer_id,
                //    'eng_remarks'             => $eng_remarks,
                   'documents_type'              => $documents_type,
                   'documents_type1'              => $documents_type1,
                   'documents_type2'              => $documents_type2,
                   'dc_received_sts'             => $dc_received_sts,
                   'dc_cus_signed_date'             => $dc_cus_signed_date,
                   'ir_rec_status'              => $ir_rec_status,
                   'ir_cus_signed_date'         => $ir_cus_signed_date,
                   'snr_rec_status'             => $snr_rec_status,
                   'snr_cus_signed_date'             => $snr_cus_signed_date,
                   // 'dc_file'               => $dc_file_data,
                   // 'dc_original_name'     => $dc_file_name,
                   'ir_file'           => $ir_file_names,
                   'ir_original_name'  => $ir_file_org_names,
                   'snr_file'          => $snr_file_data,
                   // 'form_unique_id'          => $form_unique_id,
                   'snr_original_name'  => $snr_file_org_names,
                   'po_form_unique_id'   => $form_main_unique_id,
                   'installation_date'         => $installation_date,
                   // 'installation_id'              => ins_no_get(),
   
                   'unique_id'              => $generated_unique_id
               ];
      
       }
      
       if ($snr_file_names && $snr_file_org_names) {

           $columns = [
               'po_num' => $po_num,
               'po_auto_id' => $po_unique_id,
               'po_date' => $po_date,
               'invoice_auto_id' => $invoice_auto_id,
               'invoice_no' => $invoice_no,
               'invoice_date' => $invoice_date,
               'consignee_unique_id' => $consignee_unique_id,
               'consignee_unique_id'   => $consignee_unique_id,
               'engineer_name'              => $engineer_id,
               'installation_com_date'             => $installation_com_date,
               'eng_remarks' => $eng_remarks,
            'engineer_id' => $engineer_id,
            //    'in_charge' => $in_charge,
               'documents_type1' => $documents_type1,
               'documents_type2' => $documents_type2,
               'snr_rec_status' => $snr_rec_status,
               'snr_cus_signed_date' => $snr_cus_signed_date,
               'snr_file' => $snr_file_names,
               'snr_original_name' => $snr_file_org_names,
               'po_form_unique_id' => $form_main_unique_id,
               'installation_date'         => $installation_date,
               'unique_id' => $generated_unique_id,
           ];
       }
       if(($file_names) && ($file_org_names)&& ($ir_file_names) && ($ir_file_org_names)) {

           $columns            = [
               'po_num'        => $po_num,
               'po_auto_id'        => $po_unique_id,
               'po_date'           => $po_date,
               'invoice_auto_id'     => $invoice_auto_id,
               'invoice_no'   => $invoice_no,
               'invoice_date'   => $invoice_date,
               'consignee_unique_id'   => $consignee_unique_id,
             'consignee_unique_id'   => $consignee_unique_id,
               'engineer_name'              => $engineer_id,
               'installation_com_date'             => $installation_com_date,
               'eng_remarks' => $eng_remarks,
           'engineer_id' => $engineer_id,
            //    'eng_remarks'             => $eng_remarks,
               'documents_type'              => $documents_type,
               'documents_type1'              => $documents_type1,
               'documents_type2'              => $documents_type2,
               'dc_received_sts'             => $dc_received_sts,
               'dc_cus_signed_date'             => $dc_cus_signed_date,
               'ir_rec_status'              => $ir_rec_status,
               'ir_cus_signed_date'         => $ir_cus_signed_date,
               // 'snr_rec_status'             => $snr_rec_status,
               // 'snr_cus_signed_date'             => $snr_cus_signed_date,
               'dc_file'               => $file_names,
               'dc_original_name'     => $file_org_names,
               'ir_file'           => $ir_file_names,
               'ir_original_name'  => $ir_file_org_names,
               // 'form_unique_id'          => $form_unique_id,
               'snr_file'          => $snr_file_names,
               // 'unique_id'          => $unique_id,
               'snr_original_name'  => $snr_file_org_names,
               // 'installation_id'              => ins_no_get(),
               'po_form_unique_id'   => $form_main_unique_id,
               'installation_date'         => $installation_date,
               'unique_id'              => $generated_unique_id,
           ];
       }
       if ($file_names && $file_org_names && $snr_file_names && $snr_file_org_names && $ir_file_names && $ir_file_org_names) {
           // Update all file details including IR
           $columns = [
               'po_num' => $po_num,
               'po_auto_id' => $po_unique_id,
               'po_date' => $po_date,
               'invoice_auto_id' => $invoice_auto_id,
               'invoice_no' => $invoice_no,
               'invoice_date' => $invoice_date,
               'consignee_unique_id' => $consignee_unique_id,
             'consignee_unique_id'   => $consignee_unique_id,
               'engineer_name'              => $engineer_id,
               'installation_com_date'             => $installation_com_date,
               'eng_remarks' => $eng_remarks,
            'engineer_id' => $engineer_id,
            //    'eng_remarks'             => $eng_remarks,
               'documents_type' => $documents_type,
               'documents_type1' => $documents_type1,
               'documents_type2' => $documents_type2,
               'dc_received_sts' => $dc_received_sts,
               'dc_cus_signed_date' => $dc_cus_signed_date,
               'ir_rec_status' => $ir_rec_status,
               'ir_cus_signed_date' => $ir_cus_signed_date,
               'snr_rec_status' => $snr_rec_status,
               'snr_cus_signed_date' => $snr_cus_signed_date,
               'dc_file' => $file_names,
               'dc_original_name' => $file_org_names,
               'ir_file' => $ir_file_names,
               'ir_original_name' => $ir_file_org_names,
               'snr_file' => $snr_file_names,
               'snr_original_name' => $snr_file_org_names,
               'po_form_unique_id' => $form_main_unique_id,
               'installation_date'         => $installation_date,
               'unique_id' => $generated_unique_id,
           ];
       } 
       // Check if only DC and SNR file names and original names are present
       if ($file_names && $file_org_names && $snr_file_names && $snr_file_org_names) {
           // Update only DC and SNR file details
           $columns = [
               'po_num' => $po_num,
               'po_auto_id' => $po_unique_id,
               'po_date' => $po_date,
               'invoice_auto_id' => $invoice_auto_id,
               'invoice_no' => $invoice_no,
               'invoice_date' => $invoice_date,
               'consignee_unique_id' => $consignee_unique_id,
             'consignee_unique_id'   => $consignee_unique_id,
               'engineer_name'              => $engineer_id,
               'installation_com_date'             => $installation_com_date,
               'eng_remarks' => $eng_remarks,
           'engineer_id' => $engineer_id,
            //    'engineer_name' => $engineer_name,
               'documents_type' => $documents_type,
               'documents_type1' => $documents_type1,
               'documents_type2' => $documents_type2,
               'dc_received_sts' => $dc_received_sts,
               'dc_cus_signed_date' => $dc_cus_signed_date,
               'snr_rec_status' => $snr_rec_status,
               'snr_cus_signed_date' => $snr_cus_signed_date,
               'dc_file' => $file_names,
               'dc_original_name' => $file_org_names,
               'snr_file' => $snr_file_names,
               'snr_original_name' => $snr_file_org_names,
               'po_form_unique_id' => $form_main_unique_id,
               'installation_date'         => $installation_date,
               'unique_id' => $generated_unique_id,
           ];
       }
    
$server = "localhost";
$user = "root"; 
$pass = ""; 
$dbname = "elcot_ots";
$conn1 = mysqli_connect($server, $user, $pass, $dbname);
if (!$conn1) {
    die("Connection failed: " . mysqli_connect_error());
}
echo $invoice_no;
$invoice_no = isset($_POST['invoice_no']) ? trim($_POST['invoice_no']) : '';

if (!empty($invoice_no)) {
    // Prepare SQL query
    $check_query = "SELECT count(invoice_no) as count FROM $table_sub WHERE is_delete = 0 AND invoice_no = '$invoice_no'";

    // Prepare statement
    $stmt = mysqli_query($conn1, $check_query);

    if ($stmt) {
        echo "hiii<br>";

        while ($row = mysqli_fetch_array($stmt, MYSQLI_ASSOC)) { 
            // Fetch count value
            echo $record_exists = ($row['count']);

            // Output result
            // echo "hello " . ($record_exists ? "Yes" : "No") . "<br>";
        }
            // Debugging output
            // echo "Query Executed Successfully!<br>";
            // echo "Invoice Number: " . htmlspecialchars($invoice_no) . "<br>";
            // echo "Record Exists: " . ($record_exists ? "Yes" : "No") . "<br>";

            // Close statement
            // mysqli_stmt_close($stmt);
        } else {
            echo "Error executing query: " . mysqli_error($conn);
        }
    } else {
        echo "Error preparing statement: " . mysqli_error($conn);
    }
} 


// Close database connection
// mysqli_close($conn);
if($record_exists != 0){
    echo "i am value 1";
echo $documents_type1;

       echo "UPDATE $table_sub SET 
    ir_file = '$ir_file_names', 
    ir_original_name = '$ir_file_org_names', 
    ir_rec_status = '$ir_rec_status',
    ir_cus_signed_date = '$ir_cus_signed_date',
     snr_file = '$snr_file_names', 
     snr_rec_status ='$snr_rec_status',
     snr_cus_signed_date = '$snr_cus_signed_date',


    snr_original_name = '$snr_file_org_names' ,
    documents_type1 = '$documents_type1',
    documents_type2 = '$documents_type2',
    
    WHERE invoice_no = $invoice_no";

$update_query = "UPDATE $table_sub SET 
ir_file = '$ir_file_names', 
ir_original_name = '$ir_file_org_names',
 ir_rec_status = '$ir_rec_status',
    ir_cus_signed_date = '$ir_cus_signed_date', 
snr_file = '$snr_file_names', 
snr_rec_status ='$snr_rec_status',
snr_cus_signed_date = '$snr_cus_signed_date',
snr_original_name = '$snr_file_org_names',
documents_type1 = '$documents_type1',
documents_type2 = '$documents_type2'
WHERE invoice_no = '".$invoice_no."'"; // Ensure correct condition

// Execute Query
if (mysqli_query($conn1, $update_query)) {
echo "Record updated successfully!";
} else {
echo "Error updating record: " . mysqli_error($conn1);
}


    }
   else if($record_exists == 0) {
    echo "i am zero";
    // **INSERT Query**
    echo "INSERT INTO $table_sub 
    (po_num, po_auto_id, po_date, invoice_auto_id, invoice_no, invoice_date, 
    consignee_unique_id, engineer_name, installation_com_date, eng_remarks, 
    documents_type, dc_received_sts, dc_cus_signed_date, ir_rec_status, ir_cus_signed_date, 
    snr_rec_status, snr_cus_signed_date, dc_file, dc_original_name, ir_file, 
    ir_original_name, snr_file, snr_original_name, dc_required, po_form_unique_id, 
    installation_date, unique_id) 
    VALUES 
    ('$po_num', '$po_unique_id', '$po_date', '$invoice_auto_id', '$invoice_no', '$invoice_date',
    '$consignee_unique_id', '$engineer_id', '$installation_com_date', '$eng_remarks',
    '$documents_type', '$dc_received_sts', '$dc_cus_signed_date', '$ir_rec_status', '$ir_cus_signed_date',
    '$snr_rec_status', '$snr_cus_signed_date', '$file_names', '$file_org_names', '$ir_file',
    '$ir_original_name', '$snr_file', '$snr_original_name', '$dc_required', '$form_main_unique_id',
    '$installation_date', '$generated_unique_id')";
    $insert_query = "INSERT INTO $table_sub 
    (po_num, po_auto_id, po_date, invoice_auto_id, invoice_no, invoice_date, 
    consignee_unique_id, engineer_name, installation_com_date, eng_remarks, 
    documents_type, dc_received_sts, dc_cus_signed_date, ir_rec_status, ir_cus_signed_date, 
    snr_rec_status, snr_cus_signed_date, dc_file, dc_original_name, ir_file, 
    ir_original_name, snr_file, snr_original_name, dc_required, po_form_unique_id, 
    installation_date, unique_id) 
    VALUES 
    ('$po_num', '$po_unique_id', '$po_date', '$invoice_auto_id', '$invoice_no', '$invoice_date',
    '$consignee_unique_id', '$engineer_id', '$installation_com_date', '$eng_remarks',
    '$documents_type', '$dc_received_sts', '$dc_cus_signed_date', '$ir_rec_status', '$ir_cus_signed_date',
    '$snr_rec_status', '$snr_cus_signed_date', '$file_names', '$file_org_names', '$ir_file',
    '$ir_original_name', '$snr_file', '$snr_original_name', '$dc_required', '$form_main_unique_id',
    '$installation_date', '$generated_unique_id')";

// Execute Query
if (mysqli_query($conn1, $insert_query)) {
    echo "Record inserted successfully!";
} else {
    echo "Error inserting record: " . mysqli_error($conn1);
}

}

       if ($action_obj->status) {
           $status     = $action_obj->status;
           $data       = $action_obj->data;
           $error      = '';
           $sql        = $action_obj->sql;
           if ($unique_id) {
               $msg        = "update";
           } else {
               $msg        = "create";
           }
       } else {
           $status     = $action_obj->status;
           $data       = $action_obj->data;
           $error      = $action_obj->error;
           $sql        = $action_obj->sql;
           $msg        = 'error';
       }
       // }

       $json_array   = [
           'status'    => $status,
           'data'      => $data,
           'error'     => $error,
           'msg'       => $msg,
           'sql'       => $sql

       ];

       echo json_encode($json_array);

    
    }
       
   
 

?>
