<?php
include 'header.php';
include '../config/dbconfig.php';

$btn_text           = "Save";
$btn_action         = "create";
$is_btn_disable     = "";

$unique_id          = "";

$user_type               = "";
$under_user_type        = "";
$exp_under_user_type     = "";

$is_active          = 1;

$consignee_unique_id = isset($_GET['consignee_unique_id']) ? $_GET['consignee_unique_id'] : '';
$invoice_no = isset($_GET['invoice_no']) ? $_GET['invoice_no'] : '';


if (!empty($invoice_no)) {  // Ensure invoice_no is not empty

    $where = ["invoice_no" => $invoice_no];
    $table = "view_installation_followups";

    $columns = [
        "po_unique_id",
        "po_num",
        "po_date",
        "con_contact_name",
        "con_address",
        "invoice_auto_id",
        "invoice_no",
        "invoice_date",
        "form_main_unique_id",
        "consignee_unique_id",
        "dc_required",
        "dc_file_name",
        "ir_file_name",
        "file_invoice"
    ];

    $table_details = [$table, $columns];

    $result_values = $pdo->select($table_details, $where);

    // Debugging (Remove this in production)
    // print_r($result_values);

    if ($result_values && $result_values->status && !empty($result_values->data)) { 
        // Corrected accessing the data
        $result_values      = $result_values->data;
            $po_num         = $result_values[0]["po_num"];
            $con_contact_name          = $result_values[0]["con_contact_name"];
            $con_address          = $result_values[0]["con_address"];
            $invoice_no    = $result_values[0]["invoice_no"];
            $dc_required         = $result_values[0]["dc_required"];
            $consignee_unique_id         = $result_values[0]["consignee_unique_id"];
            $orgDate = $result_values[0]["po_date"];  
            $po_date = date("d-m-Y", strtotime($orgDate));
            $dc_file_name = $result_values[0]["dc_file_name"];  
            $ir_file_name = $result_values[0]["ir_file_name"];  
            $file_invoice = $result_values[0]["file_invoice"];  
            if($result_values[0]["invoice_date"]==''){
                $invoice_date='';
            }
            else{
                $orgDate1 = $result_values[0]["invoice_date"];  
                $invoice_date = date("d-m-Y", strtotime($orgDate1));
            }

        $btn_text   = "Update";
        $btn_action = "update";
    } else {
        $btn_text       = "Error";
        $btn_action     = "error";
        $is_btn_disable = "disabled='disabled'";
    }
}

?>

<style>
    .head_po {
        font-size: 14px;
        margin-bottom: 5px;
    }



    /* checkbox design start */
    .container {
        display: block;
        position: relative;
        padding-left: 35px;
        margin-bottom: 9px;
        cursor: pointer;
        font-size: 15px;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }

    /* Hide the browser's default checkbox */
    .container input {
        position: absolute;
        opacity: 0;
        cursor: pointer;
        height: 0;
        width: 0;
    }

    /* Create a custom checkbox */
    .checkmark {
        position: absolute;
        top: 0;
        left: 0;
        height: 16px;
        width: 16px;
        background-color: #eee;
    }

    /* On mouse-over, add a grey background color */
    .container:hover input~.checkmark {
        background-color: #ccc;
    }

    /* When the checkbox is checked, add a blue background */
    .container input:checked~.checkmark {
        background-color: #2196F3;
    }

    /* Create the checkmark/indicator (hidden when not checked) */
    .checkmark:after {
        content: "";
        position: absolute;
        display: none;
    }

    /* Show the checkmark when checked */
    .container input:checked~.checkmark:after {
        display: block;
    }

    /* Style the checkmark/indicator */
    .container .checkmark:after {
        left: 6px;
        top: 2px;
        width: 5px;
        height: 11px;
        border: solid white;
        border-width: 0 3px 3px 0;
        -webkit-transform: rotate(45deg);
        -ms-transform: rotate(45deg);
        transform: rotate(45deg);
    }
    .log-out h4{ color:#fff;}
    .breadcrumb  i{ padding:0px; padding-right:10px;    font-size: 14px;}
    .breadcrumb{font-size: 14px;}
    .breadcrumb-item a, .breadcrumb-item.active, .breadcrumb-item + .breadcrumb-item::before{ color:#fff;     text-decoration: none;}
    .sub-hed { height:100%}
    .card {    border-radius: 10px;}
    .text_style{color: #000 !important;
        font-size: 17px;}
    .body_style{background-color: #efefef;}
    .form-label{    color: #4a4a4a;}
    .border_style .row{   }
</style>
<div class="body_style ">
<div class="sub-hed ">
    <div class="row">
    <div class="col-10 log-out">
    <h4 class="mb-sm-0"> Installation </h4>
    <div class="page-title-right">
        <ol class="breadcrumb m-0">
            <li class="breadcrumb-item">
                <i class="bi bi-arrow-left" id="backButton" style="cursor: pointer;"></i>
            </li>
            <li class="breadcrumb-item"><a href="javascript: void(0);">Settings</a></li>
            <li class="breadcrumb-item active"> Installation </li>
        </ol>
    </div>
</div>
       
    </div>
</div>
<div class="card cf m-3">
    <div class="card-body">
        <h3 class="mb-4 text_style">Installation - DC & IR Document Dispatch Details</h3>
        <div class="col-12 border_style">
        <div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po">
        <label class="form-label">PO Number</label>
    </div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $po_num; ?></div>
</div>

<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po">
        <label class="form-label">PO Date</label>
    </div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $po_date; ?></div>
</div>

<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po">
        <label class="form-label">Consignee Name</label>
    </div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $con_contact_name; ?></div>
</div>

<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po">
        <label class="form-label">Location</label>
    </div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $invoice_date; ?></div>
</div>

<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po">
        <label class="form-label">Invoice No</label>
    </div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $invoice_no; ?></div>
</div>
<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po"> <label class="form-label">Invoice Date</label></div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $invoice_date; ?></div>
</div>
<div class="row">
    <div class="col-5 head_po">
        <label class="form-label">DC Attachment</label>
    </div>
    <div class="col-1">:</div>
    <div class="col-6">
        <?php if (!empty($dc_file_name)): ?>
            <a href="<?php echo htmlspecialchars($dc_file_name); ?>" target="_blank">
                <i class="fas fa-file-pdf fa-lg text-danger"></i> 
            </a>
        <?php else: ?>
            <span>No Attachment</span>
        <?php endif; ?>
    </div>
</div>

<div class="row">
    <div class="col-5 head_po">
        <label class="form-label">IR Attachment</label>
    </div>
    <div class="col-1">:</div>
    <div class="col-6">
        <?php if (!empty($ir_file_name)): ?>
            <a href="<?php echo htmlspecialchars($ir_file_name); ?>" target="_blank">
                <i class="fas fa-file-pdf fa-lg text-danger"></i> 
            </a>
        <?php else: ?>
            <span>No Attachment</span>
        <?php endif; ?>
    </div>
</div>

<div class="row">
    <div class="col-5 head_po">
        <label class="form-label">SNR Attachment</label>
    </div>
    <div class="col-1">:</div>
    <div class="col-6">
        <?php if (!empty($file_invoice)): ?>
            <a href="<?php echo htmlspecialchars($file_invoice); ?>" target="_blank">
                <i class="fas fa-file-pdf fa-lg text-danger"></i> 
            </a>
        <?php else: ?>
            <span>No Attachment</span>
        <?php endif; ?>
    </div>
</div>

<div class="col-12 mt-2">
    <div class="table-responsive mb-4">
        <table class="table table-striped table-bordered align-middle  mb-0 small_table">
            <thead class="table-light">
                <tr>
                <th>S.No</th>
                <th scope="col">Item Code</th>
                <th scope="col">Item Details</th>
                <th scope="col">Invoice QTY</th>
                <th scope="col">Delivery Due Date</th>
</tr></thead><tbody>
<?php
$where1 = "consignee_id = '" . $consignee_unique_id . "' AND is_delete='0'";
$table1 = "invoice_creation";
$columns1 = [
    "item_code",
    "product",
    "invoice_qty",
    "(SELECT DATE_FORMAT(delivery_date, '%d-%m-%Y') FROM dispatch_list 
        WHERE dispatch_list.po_form_unique_id = " . $table1 . ".po_unique_id 
        LIMIT 1 ) AS delivery_date", 
    "unique_id",
    "po_unique_id"
];

$table_details1 = [
    $table1,
    $columns1
];

$values_product = $pdo->select($table_details1, $where1);

// Initialize output string
$output = '';

if (isset($values_product->data) && is_array($values_product->data) && count($values_product->data) > 0) {
    $product_array = $values_product->data;
    $j = 1;

    foreach ($product_array as $product) {
        $output .= "<tr>";
        $output .= "<td>" . $j . "</td>";
        $output .= "<td>" . htmlspecialchars($product['item_code']) . "</td>";
        $output .= "<td>" . htmlspecialchars($product['product']) . "</td>";
        $output .= "<td>" . htmlspecialchars($product['invoice_qty']) . "</td>";
        $output .= "<td>" . htmlspecialchars($product['delivery_date']) . "</td>";
        $output .= "</tr>";

        $j++;
    }
} else {
    $output .= "<tr><td colspan='5'>No data found</td></tr>";
}

echo $output;
?>
</tbody>
</table>
</div>
<?php
                    // $where      = [
                    //     "consignee_unique_id" => $unique_id
                    // ];
                    $where      = "consignee_unique_id='".$consignee_unique_id."' and invoice_no='".$invoice_no."' AND is_delete=0";

                    $table_sub_dc      =  "dc_ir_doc_dispatch_details";
                    $columns    = [
                        "po_form_unique_id",
                        "dc_dispatch_mode",
                        "dc_pod_no",
                        "dc_pod_date",
                        "ir_dispatch_mode",
                        "ir_pod_no",
                        "ir_pod_date",
                        "name_of_courier",
                        "ins_name_of_courier",
                        "snr_dispatch_mode",
                        "snr_pod_no",
                        "snr_pod_date",
                        "snr_name_courier",
                        "unique_id",
                    ];
                    $table_details   = [
                        $table_sub_dc,
                        $columns
                    ];
                    $result_values_data  = $pdo->select($table_details, $where);
                    // print_r($result_values_data);
                    if ($result_values_data->status) {
                        $result_values_data      = $result_values_data->data;
                        $dc_dispatch_mode    = $result_values_data[0]["dc_dispatch_mode"];
                        $name_of_courier = $result_values_data[0]["name_of_courier"];
                        $dc_pod_no          = $result_values_data[0]["dc_pod_no"];
                        $dc_pod_date          = $result_values_data[0]["dc_pod_date"];
                        $ir_dispatch_mode          = $result_values_data[0]["ir_dispatch_mode"];
                        $ins_name_of_courier = $result_values_data[0]["ins_name_of_courier"];
                        $ir_pod_no          = $result_values_data[0]["ir_pod_no"];
                        $ir_pod_date         = $result_values_data[0]["ir_pod_date"];
                        $snr_dispatch_mode          = $result_values_data[0]["snr_dispatch_mode"];
                        $snr_pod_no          = $result_values_data[0]["snr_pod_no"];
                        $snr_pod_date          = $result_values_data[0]["snr_pod_date"];
                        $snr_name_courier = $result_values_data[0]["snr_name_courier"];
                        $unique_id         = $result_values_data[0]["unique_id"];
                        // $exp_under_user_type  = explode(",", $under_user_type);
                        $btn_text           = "Update";
                        $btn_action         = "update";
                    } else {
                        $btn_text           = "Error";
                        $btn_action         = "error";
                        $is_btn_disable     = "disabled='disabled'";
                    }
                    $dc_dispatch_mode_options      = [
                        [
                            "id"    => 'Hand Delivery',
                            "text"  => "Hand Delivery"
                        ],
                        [
                            "id"    => 'Courier',
                            "text"  => "Courier"
                        ],
                        [
                            "id"    => 'Transporter',
                            "text"  => "Transporter"
                        ],
                    ];
                    $dc_dispatch_mode_options    = select_option($dc_dispatch_mode_options, "Select Dispatch Mode", $dc_dispatch_mode);
                    $ir_dispatch_mode_options      = [
                        [
                            "id"    => 'Hand Delivery',
                            "text"  => "Hand Delivery"
                        ],
                        [
                            "id"    => 'Courier',
                            "text"  => "Courier"
                        ],
                        [
                            "id"    => 'Transporter',
                            "text"  => "Transporter"
                        ],
                    ];
                    $ir_dispatch_mode_options    = select_option($ir_dispatch_mode_options, "Select Ir Dispatch Mode", $ir_dispatch_mode);
                    $snr_dispatch_mode_options      = [
                        [
                            "id"    => 'Hand Delivery',
                            "text"  => "Hand Delivery"
                        ],
                        [
                            "id"    => 'Courier',
                            "text"  => "Courier"
                        ],
                        [
                            "id"    => 'Transporter',
                            "text"  => "Transporter"
                        ],
                    ];
                    $snr_dispatch_mode_options    = select_option($snr_dispatch_mode_options, "Select Snr Dispatch Mode", $snr_dispatch_mode);
                    ?>
                    <?php 
                    //  $where      = [
                    //     "consignee_unique_id" => $unique_id
                    // ];
                    $where_1      = "consignee_unique_id='$consignee_unique_id' AND invoice_no='$invoice_no' AND is_delete=0";
                    // AND invoice_no='$invoice_no'

                    $table_ins_det      =  "installation_details";
                    $columns_1    = [
                        "documents_type",
                        "documents_type1",
                        "documents_type2",
                        "without_snr",

                       
                    ];
                    $table_details_1   = [
                        $table_ins_det,
                        $columns_1
                    ];
                    $result_values_data_sts  = $pdo->select($table_details_1, $where_1);
                    // print_R($result_values_data_sts);
                    if ($result_values_data_sts->status) {
                        $result_values_data_status      = $result_values_data_sts->data;
                        $dc_sts    = $result_values_data_status[0]["documents_type"];
                        $ir_sts = $result_values_data_status[0]["documents_type1"];
                        $snr_sts = $result_values_data_status[0]["documents_type2"];
                        $without_snr = $result_values_data_status[0]["without_snr"];
                       
                       
                        // $exp_under_user_type  = explode(",", $under_user_type);
                        $btn_text           = "Update";
                        $btn_action         = "update";
                    } else {
                        $btn_text           = "Error";
                        $btn_action         = "error";
                        $is_btn_disable     = "disabled='disabled'";
                    }
                    ?>                        


<br>
<h6>Delivery Document</h6>
<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po">
        <label class="form-label">DC Dispatch Mode</label>
    </div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $dc_dispatch_mode; ?></div>
</div>

<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po">
        <label class="form-label">Name of the Person/Courier or Transporter Name</label>
    </div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $name_of_courier; ?></div>
</div>

<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po">
        <label class="form-label">POD No.</label>
    </div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $dc_pod_no; ?></div>
</div>
<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po">
        <label class="form-label">POD Date</label>
    </div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $dc_pod_date; ?></div>
</div>
<h6>Installation Document</h6>
<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po">
        <label class="form-label">IR Dispatch Mode</label>
    </div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $ir_dispatch_mode; ?></div>
</div>

<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po">
        <label class="form-label">Name of the Person/Courier or Transporter Name</label>
    </div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $ins_name_of_courier; ?></div>
</div>

<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po">
        <label class="form-label">POD No.</label>
    </div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $ir_pod_no; ?></div>
</div>
<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po">
        <label class="form-label">POD Date</label>
    </div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $ir_pod_date; ?></div>
</div>
<h6>Signed Document</h6>
<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po">
        <label class="form-label">Snr Dispatch Mode</label>
    </div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $snr_dispatch_mode; ?></div>
</div>

<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po">
        <label class="form-label">Name of the Person/Courier or Transporter Name</label>
    </div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $snr_pod_no; ?></div>
</div>

<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po">
        <label class="form-label">POD No.</label>
    </div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $snr_pod_date; ?></div>
</div>
<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po">
        <label class="form-label">POD Date</label>
    </div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $snr_name_courier; ?></div>
</div>
 </div>
</div>
            </div>
        </div>
    </form>
    <!-- <div class="form-group row ">
            <div class="col-md-12 mb-3" align="center">
            <button type="button"  id="submitButton" class="btn btn-primary waves-effect waves-light"onclick="dispatch_save()">Update</button>
               
            </div>
        </div> -->

            </div> 
               
        </div>
    </div>
    </div>
</div>
</div>
<!-- <?php
        $where      = [
            "consignee_unique_id" => $consignee_unique_id,
            "invoice_no" => $invoice_no,

            "is_delete" => 0,
            
        ];
// print_r($where);
        $table_sub_install      =  "dc_ir_doc_dispatch_details";

        $columns    = [
            "po_form_unique_id",
            "po_num",
            "po_date",
            "consignee_unique_id ",
            "invoice_no",
            "invoice_date",
            "dc_dispatch_mode",
            "name_of_courier",
            "dc_pod_no",
            "dc_pod_date",
            "ir_dispatch_mode",
            "ins_name_of_courier",
            "ir_pod_no",
            "ir_pod_date",
        ];

        $table_details   = [
            $table_sub_install,
            $columns
        ];

        $result_values_data  = $pdo->select($table_details, $where);
// print_r($result_values_data);die();
        if ($result_values_data->status) {

            $result_values_data      = $result_values_data->data;
            $po_num    = $result_values_data[0]["po_num"];
            $po_date          = $result_values_data[0]["po_date"];
            $consignee_unique_id          = $result_values_data[0]["consignee_unique_id"];
            $invoice_no          = $result_values_data[0]["invoice_no"];
            $invoice_date          = $result_values_data[0]["invoice_date"];
            $dc_dispatch_mode          = $result_values_data[0]["dc_dispatch_mode"];
            $name_of_courier          = $result_values_data[0]["name_of_courier"];
            $dc_pod_no         = $result_values_data[0]["dc_pod_no"];
            $dc_pod_date         = $result_values_data[0]["dc_pod_date"];
            $ir_dispatch_mode = $result_values_data[0]["ir_dispatch_mode"];
            $ins_name_of_courier         = $result_values_data[0]["ins_name_of_courier"];
            $ir_pod_no         = $result_values_data[0]["ir_pod_no"];
            $ir_pod_date         = $result_values_data[0]["ir_pod_date"];
           
        
            $btn_text           = "Update";
            $btn_action         = "update";
        } else {
            $btn_text           = "Error";
            $btn_action         = "error";
            $is_btn_disable     = "disabled='disabled'";
        }


        ?>
     -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>        
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>

document.getElementById("backButton").addEventListener("click", function() {
        window.location.href = "list.php"; // Redirects to list.php
    });
</script>
