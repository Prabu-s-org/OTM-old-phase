<?php include 'header.php'?>
<style>
body {
    overflow: hidden;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<!-- Include SweetAlert CSS and JavaScript -->
<link rel="stylesheet" href="https://unpkg.com/sweetalert/dist/sweetalert.css">
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <!-- Include SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Include jQuery if not already included -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!-- Your custom styles and scripts -->
</head>
<script>
  // Login only Sweeet Alert Functions
  function log_sweetalert(msg='',url='',callback ='') {
	// alert();
  
  switch (msg) {
	case "create":
	  Swal.fire({
		  icon: 'success',
		  title: 'Successfully Saved',
		  showConfirmButton: true,
		  timer: 2000,
		  timerProgressBar: true,
		  onClose: () => {
			window.location = url;
		  }
	  });
	break;

	case "success_login":
	  Swal.fire({
		  type: "success",
		  icon: 'success',
		  title: 'Successfully Login',
		  showConfirmButton: true,
		  timer: 2000,
		  onClose: () => {
			window.location = url;
		  }
	  });
	break;

	case "update":
	  Swal.fire({
		  icon: 'success',
		  title: 'Successfully Updated',
		  showConfirmButton: true,
		  timer: 2000,
		  timerProgressBar: true,
		  // onClose: () => {
		  //   window.location = url;
		  // }
	  });
	break;

	case "error":
	  Swal.fire({
		  icon: 'error',
		  title: 'Error Occured',
		  showConfirmButton: true,
		  timer: 2000,
		  timerProgressBar: true,
		  onClose: () => {
			// alert("Hi");
		  }
	  });
	break;

	case "network_err":
	  Swal.fire({
		  icon: 'error',
		  title: 'Network Error Occured',
		  showConfirmButton: true,
		  timer: 2000,
		  timerProgressBar: true,
		  onClose: () => {
			// alert("Hi");
		  }
	  });
	break;

	

	case "already":
	  Swal.fire({
		  icon: 'warning',
		  title: 'Already Exist',
		  showConfirmButton: true,
		  timer: 2000,
		  timerProgressBar: true,
		  onClose: () => {
			// alert("Hi");
		  }
	  });
	break;

	case "no_internet":
	  Swal.fire({
		  icon: 'warning',
		  title: 'Please Check Your Internet Connection!',
		  showConfirmButton: true,
		  timer: 2000,
		  timerProgressBar: true,
		  onClose: () => {
			// alert("Hi");
		  }
	  });
	break;

	case "delete":
	  return Swal.fire({
		title: 'Are you sure to Delete?',
		text: "You won't be able to revert this!",
		icon: 'warning',
		showCancelButton: true,
		confirmButtonColor: '#3085d6',
		cancelButtonColor: '#d33',
		confirmButtonText: 'Yes, delete it!',
		preConfirm: () => {
		  return true;
		}
	  });
	break;

	case "success_delete":
	  Swal.fire({
		  icon: 'success',
		  title: 'Deleted!',
		  showConfirmButton: true,
		  timer: 1500,
		  timerProgressBar: true
	  });
	break;

	case "form_alert":
	  Swal.fire({
		icon: 'info',
		title: 'Fill Out All Mantantory Fields',
		showConfirmButton: true,
		timer: 2000,
		timerProgressBar: true
	  })
  break;
	
	case "approve":
	  Swal.fire({
		  icon: 'success',
		  title: 'Successfully Approved',
		  showConfirmButton: true,
		  timer: 2000,
		  onClose: () => {
			window.location = url;
		  }
	  });
	break; 

	case "convert":
	  Swal.fire({
		  icon: 'success',
		  title: 'Successfully Converted',
		  showConfirmButton: true,
		  timer: 2000,
		  onClose: () => {
			window.location = url;
		  }
	  });
  break;    

  case "incorrect":
	  Swal.fire({
		  icon: 'error',
		  title: 'Incorrect <br /> UserName Or Password',
		  // imageUrl:'img/emoji/invalid.webp',
		  showConfirmButton: true,
		  timer: 2000,
		  timerProgressBar: true,
		  onClose: () => {
			// alert("Hi");
		  }
	  });
  break;
  
  case "empty":
	  Swal.fire({
		icon: 'info',
		title: 'Enter Username and Password!',
		showConfirmButton: true,
		timer: 2000,
		timerProgressBar: true
	  })
	break;
  }
}
</script>

<body>
<div class="over-page">
	<div class="login-bg">
	<img src="assets/img/login-img.png">
	<h3>Welcome To Elcot Installation</h3>
	<p>Login into Dashboard</p>
	<div class="row">
	<div class="col-12">
	<ul class="bg-bubbles">
	
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		
	</ul>
	</div>
	</div>
	</div>
	<div class="container-fluid">
	<div class="login-form">
	 
	  <div class="row">
	  <div class="col-12 img-text">
	   <input type="text" name="user_name" id="user_name" placeholder="Enter your username" class="input-group"> 
	  <img src="assets/img/user.png">
	  </div>
	   <div class="col-12 img-text">
	 <input type="password" name="password" id="password" placeholder="Enter your password" class="input-group no-mar" onclick="togglePasswordVisibility()">
<img src="assets/img/padlock.png">
	  </div>
	    <div class="col-12 sing-btn">
		<button class="btn btn-primary w-100" type="button" onclick="login()" >Login</button>
		<!-- <button onclick="window.location.href='list.php';">Login</button> -->
	  </div>
	</div>
	</div>
</div>

<script>
function login() {
  if (!is_online()) {
    sweetalert("no_internet");
    return false;
  }

  let user_name = document.getElementById("user_name").value.trim();
  let password = document.getElementById("password").value.trim();
//   alert(user_name);

  if (user_name && password) {
    fetch("crud.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: `user_name=${encodeURIComponent(user_name)}&password=${encodeURIComponent(password)}&action=loginUser`
    })
    .then(response => response.text()) // First, get response as text
    .then(text => {
      try {
        let data = JSON.parse(text.trim()); // Ensure proper JSON parsing
        console.log("Server Response:", data);
        
        if (data.status) {
          let url = (password === "password") ? "password/update&default=true" : "list.php";
          log_sweetalert(data.msg, url);
          setTimeout(() => {
            window.location.href = url;
          }, 1000);
        } else {
          log_sweetalert(data.msg, "");
        }
      } catch (error) {
        console.error("Invalid JSON response:", text); // Log raw response
        log_sweetalert("error", "Unexpected response from the server.");
      }
    });
  } else {
    log_sweetalert("Please fill in all fields.");
  }
}

  
  function is_online() {
	return true;
	// return(navigator.onLine);
	return false;
  }
  
 
  $('body').on('keyup', function (evt) {
  if (evt.keyCode == 13) {
	// Simulate clicking on the submit button.
	login();
  }
  }); 
  
  function togglePasswordVisibility() {
        var passwordInput = document.getElementById("password");

        // Toggle the type attribute of the password input
        if (passwordInput.type === "password") {
            passwordInput.type = "text";
        } else {
            passwordInput.type = "password";
        }
    }
  </script>


<?php include 'footer.php'?>

