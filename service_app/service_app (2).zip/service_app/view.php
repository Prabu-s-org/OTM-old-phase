<?php
error_log(0);
include 'header.php';
?>
<?php
include 'header.php';
// include '../../config/dbconfig.php';
include '../config/dbconfig.php';


?>
<?php
// Form variables
$btn_text           = "Save";
$btn_action         = "create";
$is_btn_disable     = "";

$unique_id          = "";

$user_type               = "";
$under_user_type        = "";
$exp_under_user_type     = "";

$is_active          = 1;

$consignee_unique_id = isset($_GET['consignee_unique_id']) ? $_GET['consignee_unique_id'] : '';
$invoice_no = isset($_GET['invoice_no']) ? $_GET['invoice_no'] : '';
// print_r($consignee_unique_id);

if (isset($_GET["invoice_no"])) {
    if (!empty($_GET["invoice_no"])) {

        $invoice_auto_id  = $_GET["invoice_no"];
    //    print_r($invoice_auto_id);
        $where      = [
            "invoice_no" => $invoice_auto_id
        ];

        $table      =  "view_installation_followups";

        $columns    = [
            "po_unique_id",
            "po_num",
            "po_date",
            "con_contact_name",
            "con_address",
            "invoice_auto_id",
            "invoice_no",
            "invoice_date",
            "form_main_unique_id",
            "consignee_unique_id",
            "ins_reqired",
            "dc_required",
            "(SELECT staff_name FROM view_login WHERE view_login.unique_id = view_installation_followups.engineer_name) AS engineer_name",
            "DATE_FORMAT(date, '%d-%m-%Y') AS date",
            "in_charge",
            "(SELECT district_name FROM district_creation WHERE district_creation.unique_id = view_installation_followups.con_district) AS con_district",
            "con_pincode",   
            "sign_reject_reason", 
            "installation_status" ,
            "engg_type",
            "dc_file_name",
            "ir_file_name",
            "file_invoice",
        ];

        $table_details   = [
            $table,
            $columns
        ];

        $result_values  = $pdo->select($table_details, $where);
// print_r($result_values);
        if ($result_values->status) {
            $result_values      = $result_values->data;

            $po_unique_id          = $result_values[0]["po_num"];
            $con_contact_name      = $result_values[0]["con_contact_name"];
            $con_address          = $result_values[0]["con_address"];
            $invoice_no           = $result_values[0]["invoice_no"];
            $consignee_unique_id  = $result_values[0]["consignee_unique_id"];
            $dc_required          = $result_values[0]["dc_required"];
            $ins_reqired          = $result_values[0]["ins_reqired"];
            $engineer_name    = $result_values[0]["engineer_name"];  
            $installation_com_date = $result_values[0]["date"];  
            $eng_remarks          = $result_values[0]["in_charge"];  
            $con_district = $result_values[0]["con_district"];
            $con_pincode = $result_values[0]["con_pincode"];
            $sign_reject_reason = $result_values[0]["sign_reject_reason"];
            $installation_status = $result_values[0]["installation_status"];
            $engg_type = $result_values[0]["engg_type"];

            $dc_file_name = $result_values[0]["dc_file_name"];
            $ir_file_name = $result_values[0]["ir_file_name"];
            $file_invoice = $result_values[0]["file_invoice"];
              
            // Format PO Date
            $orgDate = $result_values[0]["po_date"];
            $po_date = date("d-m-Y", strtotime($orgDate));

            // Format Invoice Date
            if($result_values[0]["invoice_date"]==''){
                $invoice_date = '';
            } else {
                $orgDate1 = $result_values[0]["invoice_date"];
                $invoice_date = date("d-m-Y", strtotime($orgDate1));
            }

            $btn_text   = "Update";
            $btn_action = "update";
        } else {
            $btn_text   = "Error";
            $btn_action = "error";
            $is_btn_disable = "disabled='disabled'";
        }
    }
}

$engineer_name_optionss = engineer_name();
$engineer_name_option = select_option($engineer_name_optionss, "Select Eng Name", $engineer_name_inv);
// $engineer_name_optionss = user_engineer_name();
// $engineer_name_option = select_option($engineer_name_optionss, "Select Eng Name", $engineer_name);


$active_status_options   = active_status($is_active);

?>

<style>
    .head_po {
        font-size: 14px;
        margin-bottom: 5px;
    }



    /* checkbox design start */
    .container {
        display: block;
        position: relative;
        padding-left: 35px;
        margin-bottom: 9px;
        cursor: pointer;
        font-size: 15px;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }

    /* Hide the browser's default checkbox */
    .container input {
        position: absolute;
        opacity: 0;
        cursor: pointer;
        height: 0;
        width: 0;
    }

    /* Create a custom checkbox */
    .checkmark {
        position: absolute;
        top: 0;
        left: 0;
        height: 16px;
        width: 16px;
        background-color: #eee;
    }

    /* On mouse-over, add a grey background color */
    .container:hover input~.checkmark {
        background-color: #ccc;
    }

    /* When the checkbox is checked, add a blue background */
    .container input:checked~.checkmark {
        background-color: #2196F3;
    }

    /* Create the checkmark/indicator (hidden when not checked) */
    .checkmark:after {
        content: "";
        position: absolute;
        display: none;
    }

    /* Show the checkmark when checked */
    .container input:checked~.checkmark:after {
        display: block;
    }

    /* Style the checkmark/indicator */
    .container .checkmark:after {
        left: 6px;
        top: 2px;
        width: 5px;
        height: 11px;
        border: solid white;
        border-width: 0 3px 3px 0;
        -webkit-transform: rotate(45deg);
        -ms-transform: rotate(45deg);
        transform: rotate(45deg);
    }
    .log-out h4{ color:#fff;}
    .breadcrumb  i{ padding:0px; padding-right:10px;    font-size: 14px;}
    .breadcrumb{font-size: 14px;}
    .breadcrumb-item a, .breadcrumb-item.active, .breadcrumb-item + .breadcrumb-item::before{ color:#fff;     text-decoration: none;}
    .sub-hed { height:100%}
    .card {    border-radius: 10px;}
    .text_style{color: #000 !important;
        font-size: 17px;}
    .body_style{background-color: #efefef;}
    .form-label{    color: #4a4a4a;}
    .border_style .row{   }
</style>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">

<div class="body_style ">
<div class="sub-hed ">
    <div class="row">
    <div class="col-10 log-out">
    <h4 class="mb-sm-0"> Installation </h4>
    <div class="page-title-right">
        <ol class="breadcrumb m-0">
            <li class="breadcrumb-item">
                <i class="bi bi-arrow-left" id="backButton" style="cursor: pointer;"></i>
            </li>
            <li class="breadcrumb-item"><a href="javascript: void(0);">Settings</a></li>
            <li class="breadcrumb-item active"> Installation </li>
        </ol>
    </div>
</div>
       
    </div>
</div>
<div class="card cf m-3">
    <div class="card-body">
        <h3 class="mb-4 text_style">Installation Completed Details</h3>
        <div class="col-12 border_style">
        <div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po">
        <label class="form-label">PO Number</label>
    </div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $po_unique_id; ?></div>
</div>

<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po">
        <label class="form-label">PO Date</label>
    </div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $po_date; ?></div>
</div>

<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po">
        <label class="form-label">Invoice No</label>
    </div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $invoice_no; ?></div>
</div>

<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po">
        <label class="form-label">Invoice Date</label>
    </div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $invoice_date; ?></div>
</div>

<!-- <div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po">
        <label class="form-label">Department Name</label>
    </div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $department; ?></div>
</div> -->
<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po"> <label class="form-label">Consignee Name</label></div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $con_contact_name; ?></div>
</div>
<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po"> <label class="form-label">Consignee Address</label></div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $con_address; ?></div>
</div>
<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po"> <label class="form-label">District Name</label></div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $con_district; ?></div>
</div>
<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po"> <label class="form-label">Pincode</label></div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $con_pincode; ?></div>
</div>

<?php if ($installation_status == '3') { ?>
<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po"> <label class="form-label">Reject Reason</label></div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $sign_reject_reason; ?></div>
</div>
<?php } ?>

<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po"> <label class="form-label">Engg. Type</label></div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6">
        <?php 
            if ($engg_type == '2') {
                echo "Outsource Vendor";
            } elseif ($engg_type == '1') {
                echo "Own Engineer";
            } else {
                echo "N/A";
            }
        ?>
    </div>
</div>

<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po"> <label class="form-label">Engg. Name</label></div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $engineer_name; ?></div>
</div>

<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po"> <label class="form-label">Date</label></div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $installation_com_date; ?></div>
</div>

<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po"> <label class="form-label">Installation Charge</label></div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6"><?php echo $eng_remarks; ?></div>
</div>
<h5>Documents</h5>
<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po"> <label class="form-label">DC</label></div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6">
        <?php if (!empty($dc_file_name)): ?>
            <a href="<?php echo $dc_file_name; ?>" target="_blank" class="text-danger">
                <i class="fas fa-file-pdf fa-2x"></i>
            </a>
        <?php endif; ?>
    </div>
</div>

<div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po"> <label class="form-label">IR</label></div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6">
        <?php if (!empty($ir_file_name)): ?>
            <a href="<?php echo $ir_file_name; ?>" target="_blank" class="text-danger">
                <i class="fas fa-file-pdf fa-2x"></i>
            </a>
        <?php endif; ?>
    </div>
</div>

<!-- <div class="row">
    <div class="col-5 col-sm-5 col-md-5 col-lg-5 head_po"> <label class="form-label">SNR</label></div>
    <div class="col-1 col-sm-1 col-md-1 col-lg-1">:</div>
    <div class="col-6 col-sm-6 col-md-6 col-lg-6">
        <?php if (!empty($file_invoice)): ?>
            <a href="<?php echo $file_invoice; ?>" target="_blank" class="text-danger">
                <i class="fas fa-file-pdf fa-2x"></i>
            </a>
        <?php endif; ?>
    </div>
</div> -->

<!-- Include FontAwesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

 </div>
</div>
<?php
        $where      = [
            "consignee_unique_id" => $consignee_unique_id,
            "invoice_no" => $invoice_no,

            "is_delete" => 0,
            
        ];
// print_r($where);
        $table_sub_install      =  "installation_details";

        $columns    = [
            "po_form_unique_id",
            // "engineer_name",
            "(SELECT staff_name FROM view_login WHERE view_login.unique_id = installation_details.engineer_name) AS engineer_name",
            "installation_com_date",
            "cus_ack_date",
            "documents_type",
            "documents_type1",
            "documents_type2",
            "dc_received_sts",
            "dc_cus_signed_date",
            "ir_rec_status",
            "ir_cus_signed_date",
            "snr_rec_status",
            "snr_cus_signed_date",
            "dc_file",
            "ir_file",
            "snr_file",
            "unique_id",
            "consignee_unique_id",
            "dc_original_name",
            "ir_original_name",
            "snr_original_name"
        ];

        $table_details   = [
            $table_sub_install,
            $columns
        ];

        $result_values_data  = $pdo->select($table_details, $where);
// print_r($result_values_data);die();
        if ($result_values_data->status) {

            $result_values_data      = $result_values_data->data;
            $engineer_name    = $result_values_data[0]["engineer_name"];
            $installation_com_date          = $result_values_data[0]["installation_com_date"];
            $cus_ack_date          = $result_values_data[0]["cus_ack_date"];
            $documents_type          = $result_values_data[0]["documents_type"];
            $documents_type1          = $result_values_data[0]["documents_type1"];
            $documents_type2          = $result_values_data[0]["documents_type2"];
            $dc_received_sts          = $result_values_data[0]["dc_received_sts"];
            $dc_cus_signed_date         = $result_values_data[0]["dc_cus_signed_date"];
            $ir_rec_status         = $result_values_data[0]["ir_rec_status"];
            $ir_cus_signed_date = $result_values_data[0]["ir_cus_signed_date"];
            $snr_rec_status         = $result_values_data[0]["snr_rec_status"];
            $snr_cus_signed_date         = $result_values_data[0]["snr_cus_signed_date"];

            $ir_file         = $result_values_data[0]["ir_file"];
            $ir_file_show = image_view_ir_file("installation", $result_values_data[0]['consignee_unique_id'], $result_values_data[0]['ir_file']);

            $dc_file         = $result_values_data[0]["dc_file"];
            $dc_file_show = image_view_dc_file("installation", $result_values_data[0]['consignee_unique_id'], $result_values_data[0]['dc_file']);

           
            $snr_file         = $result_values_data[0]["snr_file"];
            $snr_file_show =  image_view_snr_file("installation", $result_values_data[0]['consignee_unique_id'], $result_values_data[0]['snr_file']);
           
            $dc_original_name         = $result_values_data[0]["dc_original_name"];
            $ir_original_name         = $result_values_data[0]["ir_original_name"];
            $snr_original_name         = $result_values_data[0]["snr_original_name"];


            $sign_unique_id         = $result_values_data[0]["unique_id"];
            $consignee_unique_id         = $result_values_data[0]["consignee_unique_id"];



            $btn_text           = "Update";
            $btn_action         = "update";
        } else {
            $btn_text           = "Error";
            $btn_action         = "error";
            $is_btn_disable     = "disabled='disabled'";
        }


        $dc_received_sts_options      = [
            [
                "id"    => '1',
                "text"  => "Yes"
            ],
            

        ];
        $dc_received_sts_options    = select_option($dc_received_sts_options, "Select Status", $dc_received_sts);

        $ir_rec_status_options      = [
            [
                "id"    => '1',
                "text"  => "Yes"
            ],
           

        ];

        $ir_rec_status_options    = select_option($ir_rec_status_options, "Select Status", $ir_rec_status);

        $snr_rec_status_options      = [
            [
                "id"    => '1',
                "text"  => "Yes"
            ],
           

        ];

        $snr_rec_status_options    = select_option($snr_rec_status_options, "Select Status", $snr_rec_status);

        $engineer_name_options = engineer_name();
        $engineer_name_options = select_option($engineer_name_options, "Select Eng Name", $engineer_name);
        $engineer_type_options = engineer_type();
        $engineer_type_options = select_option($engineer_type_options, "Select Eng Type", $engineer_name);
        if($engg_type =='1'){

            $engg_type_name = 'Own Engineer';
        }else{
            $engg_type_name = 'Outsource Vendor';
        }
        ?>
    
                <input class="form-control" type="hidden" id="form_unique_id" name="form_unique_id" value="<?php echo $result_values_data[0]["unique_id"] ?>">
                                <input class="form-control" type="hidden" id="unique_id" name="unique_id" value="<?php echo $result_values_data[0]["unique_id"] ?>">
                                <input class="form-control" type="hidden" id="po_unique_id" name="po_unique_id" value="<?php echo $result_values[0]["po_unique_id"] ?>">
                                <input class="form-control" type="hidden" id="po_num" name="po_num" value="<?php echo $result_values[0]["po_num"] ?>">
                                <input class="form-control" type="hidden" id="po_date" name="po_date" value="<?php echo $result_values[0]["po_date"] ?>">
                                <input class="form-control" type="hidden" id="invoice_auto_id" name="invoice_auto_id" value="<?php echo $result_values[0]["invoice_auto_id"] ?>">
                                <input class="form-control" type="hidden" id="invoice_no" name="invoice_no" value="<?php echo $result_values[0]["invoice_no"] ?>">
                                <input class="form-control" type="hidden" id="invoice_date" name="invoice_date" value="<?php echo $result_values[0]["invoice_date"] ?>">
                                <input class="form-control" type="hidden" id="consignee_unique_id" name="consignee_unique_id" value="<?php echo $result_values[0]["consignee_unique_id"] ?>">
                                <input class="form-control" type="hidden" id="po_form_unique_id" name="po_form_unique_id" value="<?php echo $result_values[0]["form_main_unique_id"] ?>">
                                <input class="form-control" type="hidden" id="dc_required" name="dc_required" value="<?php echo $result_values[0]["dc_required"] ?>">
                               <input class="form-control" type="hidden" id="ins_reqired" name="ins_reqired" value="<?php echo $result_values[0]["ins_reqired"] ?>">
    
            </div>
        </div>
    </form>
    <div class="form-group row ">
            <div class="col-md-12 mb-3" align="center">
            <button type="button"  id="submitButton" class="btn btn-primary waves-effect waves-light" onclick="installation_cu();">Update</button>
                <!-- Cancel,save and update Buttons -->
                

                <!-- <?php if ($sign_unique_id != '') { ?>
                    <button type="button"  id="submitButton"  style="display:none;"class="btn btn-primary waves-effect waves-light" onclick="installation_cu();">Update</button>
                <?php } else { ?>
                    <button type="button"  id="submitButton"  style="display:none;" class="btn btn-primary waves-effect waves-light" onclick="installation_cu();">Save</button>
                <?php } ?> -->
                
            </div>
        </div>

            </div> 
               
        </div>
    </div>

    </div>
</div>
</div>


<script>
    document.getElementById("backButton").addEventListener("click", function() {
        // alert("fgh");
        window.location.href = "list.php"; // Redirects to list.php
    });
    </script>
