<?php
session_start();
date_default_timezone_set( 'Asia/Kolkata' );
//India time ( GMT+5:30 )
// ini_set( 'max_execution_time', '0' );
header( 'Access-Control-Allow-Origin: *' );
header( 'Access-Control-Allow-Methods: POST, GET, OPTIONS' );
error_reporting( 0 );
// Import Database Common Class file
require 'dbclass.php';

// Production Server Auto Detect PHP function Start
$whitelist = array(
    '127.0.0.1',
    '::1'
);

if ( !in_array( $_SERVER[ 'REMOTE_ADDR' ], $whitelist ) ) {
    // Production Server Configuration
    $driver         = 'mysql';
    $host           = 'localhost';
    $username       = 'root';
    $password       = '';
    $databasename   = 'elcot_ots';

} else {

    // Development Server Configuration
    $driver         = 'mysql';
    $host           = 'localhost';
    $username       = 'root';
    $password       = '';
    $databasename   = 'elcot_ots';
}

$pdo            = new Db( $driver, $host, $username, $password, $databasename );

try {
    $conn = new PDO( $driver.':host='.$host.';port=3306;dbname='.$databasename, $username, $password );

    $conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
    // echo 'connected successfully';
} catch( PDOException $e )
 {
    echo $sql . '<br>' . $e->getMessage();
}

// Common Functions Import
// require_once 'comfun.php';
require_once 'SecureUPload/src/autoloader.php';
try {

    $fileUploadConfig = new Alirdn\SecureUPload\Config\SecureUPloadConfig();

    $fileUploadConfig->setArray(
        array(
            'upload_folder' => dirname( __FILE__, 2 ) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR
        )
    );

} catch ( Alirdn\SecureUPload\Exceptions\UploadFolderException $exception ) {
    echo 'Exception: ' . $exception->getMessage() . ' Code: ' . $exception->getCode() . ' Note: For more information check php error_log.';
    die();
}

?>