<?php
 session_start();

 // Set cookie expiration time to 1 hour (3600 seconds)
// session_start();
// session_set_cookie_params(3600);

ini_set('max_execution_time', '0');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');

// $date = date('Y-m-d');
// if($_SESSION['logindate'] != $date) { 
//     echo '<script>alert("Logout")</script>';
//     session_start();
//     session_destroy();//subtract new timestamp from the old one
//     header("Location: login.php"); //redirect to index.php
//     exit;
// }
// else {
//         $_SESSION['logindate'] = $date; //set new timestamp
//     }
// ini_set('session.gc_maxlifetime', 3600);


?>