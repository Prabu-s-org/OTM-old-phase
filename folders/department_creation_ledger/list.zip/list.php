<style>
   i.fa.fa-edit{
      font-size: 20px;
    color: green;
   }
   i.fa-sharp.fa-solid.fa-trash {
   font-size: 20px;
    color: green;
   }
  </style>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  
  <!-- start page title -->
  <div class="row">
      <div class="col-12">
         <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">List Department Creation</h4>

            <div class="page-title-right">
                  <ol class="breadcrumb m-0">
                     <li class="breadcrumb-item"><a href="javascript: void(0);">Admin</a></li>
                     <li class="breadcrumb-item active">Department Creation</li>
                  </ol>
            </div>

         </div>
      </div>   
  </div>
  <!-- end page title -->
  <div class="row">
     <div class="col-7">
       
     </div>
     <div class="d-grid gap-2 d-md-flex justify-content-md-end mb-3">
          <?php echo btn_add($btn_add); ?>
      </div>
  </div>
  <!----content start---------->
  <div class="row">
     <div class="col-12">
        <div class="card">
           <div class="card-body">
              <table id="department_creation_datatable" class="table table-bordered nowrap table-striped align-middle">
                 <thead>
                    <tr>
                       <th>#</th>
                       <th>Department</th>
                       <th>Description</th>
                       <th>Active Status</th>
                       <th>Action</th>
                    </tr>
                 </thead>
                 <tbody>
                  <!-- <tr>
                     <td>1</td>
                     <td>tamilnadu</td>
                     <td>erode</td>
                     <td>active</td>
                     <td><i class="fa fa-edit"></i><i class="fa-sharp fa-solid fa-trash"></i></td>
                  </tr> -->
                 </tbody>
              </table>
           </div>
        </div>
     </div>
  </div>
  <!----content start---------->